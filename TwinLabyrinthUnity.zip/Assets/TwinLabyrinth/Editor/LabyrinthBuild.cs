using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build.Reporting;
using UnityEngine;
namespace TwinLabyrinth {
 public static class LabyrinthBuild {
  const string Scene="Assets/TwinLabyrinth/Scenes/Main.unity";
  [MenuItem("Twin Labyrinth/Prepare scene")]
  public static void Prepare(){
   if(!File.Exists(Scene)){var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);new GameObject("Twin Labyrinth").AddComponent<LabyrinthApp>();EditorSceneManager.SaveScene(scene,Scene);}
   EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(Scene,true)};
   PlayerSettings.productName="Twin Labyrinth";PlayerSettings.companyName="Twin Labyrinth";PlayerSettings.runInBackground=true;
   PlayerSettings.defaultScreenWidth=1280;PlayerSettings.defaultScreenHeight=720;
   PlayerSettings.insecureHttpOption=InsecureHttpOption.DevelopmentOnly;
   var graphics=new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0]);
   var shaders=graphics.FindProperty("m_AlwaysIncludedShaders");var standard=Shader.Find("Standard");bool found=false;
   for(int i=0;i<shaders.arraySize;i++)if(shaders.GetArrayElementAtIndex(i).objectReferenceValue==standard)found=true;
   if(!found&&standard!=null){int i=shaders.arraySize;shaders.InsertArrayElementAtIndex(i);shaders.GetArrayElementAtIndex(i).objectReferenceValue=standard;graphics.ApplyModifiedProperties();}
   AssetDatabase.SaveAssets();
  }
  [MenuItem("Twin Labyrinth/Build Windows")]
  public static void Windows(){Build(BuildTarget.StandaloneWindows64,"Builds/Windows/TwinLabyrinth.exe");}
  [MenuItem("Twin Labyrinth/Build WebGL")]
  public static void WebGL(){PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Disabled;Build(BuildTarget.WebGL,"Builds/WebGL");}
  static void Build(BuildTarget target,string output){Prepare();Directory.CreateDirectory(Path.GetDirectoryName(output));var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{Scene},locationPathName=output,target=target,options=BuildOptions.None});if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Unity build failed: "+report.summary.result);}
 }
 [InitializeOnLoad] public static class FirstImport {
  static FirstImport(){EditorApplication.delayCall+=()=>{if(!File.Exists("Assets/TwinLabyrinth/Scenes/Main.unity"))LabyrinthBuild.Prepare();};}
 }
}
