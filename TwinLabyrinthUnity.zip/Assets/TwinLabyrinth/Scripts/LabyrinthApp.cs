using System;
using UnityEngine;

namespace TwinLabyrinth
{
    public sealed class LabyrinthApp : MonoBehaviour
    {
        public LabyrinthGame Game {get;private set;}
        public bool InMenu {get;private set;}
        LabyrinthWorldView view;LabyrinthSound sound;LabyrinthNetwork network;
        PlayerInput[] inputs={new PlayerInput(),new PlayerInput()};
        string mode="solo",difficulty="normal",ai="elite",roomCode="",serverUrl="http://localhost:8787",notice="";
        bool paused,mapVisible,guideVisible,recorded,ready,english;
        float sensitivity=1,brightness=1.2f,noticeUntil;Font font;GUISkin customSkin;
        Color ink=new Color(.87f,.91f,.81f),accent=new Color(.58f,.8f,.68f);
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Bootstrap(){if(FindObjectOfType<LabyrinthApp>()==null)new GameObject("Twin Labyrinth").AddComponent<LabyrinthApp>();}
        void Awake()
        {
            if(FindObjectsOfType<LabyrinthApp>().Length>1){Destroy(gameObject);return;}
            Application.targetFrameRate=60;Time.fixedDeltaTime=.02f;
            view=gameObject.AddComponent<LabyrinthWorldView>();sound=gameObject.AddComponent<LabyrinthSound>();network=gameObject.AddComponent<LabyrinthNetwork>();network.Received=Receive;
            sensitivity=PlayerPrefs.GetFloat("twin.sensitivity",1);brightness=PlayerPrefs.GetFloat("twin.brightness",1.2f);
            sound.MusicVolume=PlayerPrefs.GetFloat("twin.music",.35f);sound.EffectsVolume=PlayerPrefs.GetFloat("twin.effects",.7f);
            serverUrl=PlayerPrefs.GetString("twin.server","http://localhost:8787");
            TextAsset deployment=Resources.Load<TextAsset>("Deployment");if(deployment!=null){DeploymentConfig config=JsonUtility.FromJson<DeploymentConfig>(deployment.text);if(config!=null&&!string.IsNullOrEmpty(config.serverUrl))serverUrl=config.serverUrl;}
            #if UNITY_WEBGL && !UNITY_EDITOR
            english=true;
            #else
            try{font=Font.CreateDynamicFontFromOSFont(new[]{"Microsoft YaHei","PingFang SC","Noto Sans CJK SC","Arial"},18);}catch(Exception){english=true;}
            #endif
            Game=new LabyrinthGame(73197,"normal","solo","elite");Game.S.npcs.Clear();InMenu=true;view.Build(Game);
        }
        [Serializable] class DeploymentConfig {public string serverUrl;}
        void BeginLocal()
        {
            network.Leave();Game=new LabyrinthGame(UnityEngine.Random.Range(1,1000000000),difficulty,mode,ai);InMenu=false;paused=false;mapVisible=false;recorded=false;ready=false;view.Build(Game);sound.Begin();Capture(true);SaveSettings();
        }
        void Receive(GameState state,WorldData world)
        {
            bool fresh=InMenu||Game.S.seed!=state.seed||Game.S.mode!="remote";
            if(fresh){Game=new LabyrinthGame(state.seed,state.difficulty,"remote",state.ai);Game.Load(state,world);InMenu=false;mode="remote";paused=false;mapVisible=false;recorded=false;ready=false;view.Build(Game);sound.Begin();Capture(true);}else Game.Load(state,world);
        }
        void Menu()
        {
            network.Leave();sound.Stop();InMenu=true;paused=false;mapVisible=false;Capture(false);SaveSettings();
            Game=new LabyrinthGame(73197,"normal","solo","elite");Game.S.npcs.Clear();view.Build(Game);
        }
        void Capture(bool value){Cursor.lockState=value?CursorLockMode.Locked:CursorLockMode.None;Cursor.visible=!value;}
        void SaveSettings(){PlayerPrefs.SetFloat("twin.sensitivity",sensitivity);PlayerPrefs.SetFloat("twin.brightness",brightness);PlayerPrefs.SetFloat("twin.music",sound.MusicVolume);PlayerPrefs.SetFloat("twin.effects",sound.EffectsVolume);PlayerPrefs.SetString("twin.server",serverUrl);PlayerPrefs.Save();}
        void Pause(){if(InMenu||Game.S.status!="playing")return;paused=!paused;Capture(!paused&&!mapVisible);}
        static float Key(KeyCode positive,KeyCode negative){return (Input.GetKey(positive)?1:0)-(Input.GetKey(negative)?1:0);}
        PlayerInput Read(int i)
        {
            if(i==1&&mode=="local")return new PlayerInput {forward=Key(KeyCode.UpArrow,KeyCode.DownArrow),turn=Key(KeyCode.RightArrow,KeyCode.LeftArrow)*2*sensitivity,pitch=Key(KeyCode.Period,KeyCode.Comma),attack=Input.GetKey(KeyCode.Return)};
            return new PlayerInput {forward=Key(KeyCode.W,KeyCode.S),strafe=Key(KeyCode.D,KeyCode.A),turn=(Key(KeyCode.E,KeyCode.Q)+(mode!="local"?Key(KeyCode.RightArrow,KeyCode.LeftArrow):0))*2*sensitivity,pitch=Key(KeyCode.R,KeyCode.F),attack=Input.GetKey(KeyCode.J)||Input.GetKey(KeyCode.Space)||(Cursor.lockState==CursorLockMode.Locked&&Input.GetMouseButton(0))};
        }
        void Update()
        {
            if(Game==null)return;
            if(Input.GetKeyDown(KeyCode.N))sound.MusicMuted=!sound.MusicMuted;
            if(!InMenu){if(Input.GetKeyDown(KeyCode.Escape)||Input.GetKeyDown(KeyCode.P))Pause();if(Input.GetKeyDown(KeyCode.M)&&Game.S.status=="playing"){mapVisible=!mapVisible;Capture(!paused&&!mapVisible);}if(Input.GetKeyDown(KeyCode.T)&&mode!="remote")BeginLocal();}
            bool control=!InMenu&&!paused&&!mapVisible&&Game.S.status=="playing";int role=mode=="remote"?network.Role:0;
            inputs[0]=control?Read(0):new PlayerInput();inputs[1]=control?Read(1):new PlayerInput();
            if(control&&Cursor.lockState==CursorLockMode.Locked){float turn=Mathf.Clamp(Input.GetAxisRaw("Mouse X"),-30,30)*.028f*sensitivity,pitch=Mathf.Clamp(Input.GetAxisRaw("Mouse Y"),-30,30)*.013f*sensitivity;
                if(mode=="remote"){network.Look.a+=turn;network.Look.pitch+=pitch;}else{Game.S.players[0].a+=turn;Game.S.players[0].pitch=Mathf.Clamp(Game.S.players[0].pitch+pitch,-.6f,.6f);}}
            network.Input=control?inputs[0]:new PlayerInput();
            if(!InMenu&&Game.S.status!="playing"&&!recorded){recorded=true;Capture(false);string key="twin.best."+Game.S.difficulty+"."+Game.S.mode;if(Game.S.status=="won"&&Game.S.t<PlayerPrefs.GetFloat(key,float.MaxValue)){PlayerPrefs.SetFloat(key,Game.S.t);notice=Text("New personal record!","新的个人纪录！");noticeUntil=Time.unscaledTime+999;}PlayerPrefs.Save();}
            if(InMenu)Game.S.players[0].a+=(Mathf.Sin(Time.time*.15f)*.1f)*Time.deltaTime;
            view.Display(Game,role,mode=="local"&&!InMenu,InMenu,brightness,sound.Flash);
            sound.Tick(InMenu?null:Game,role,paused||mapVisible);
        }
        void FixedUpdate(){if(Game!=null&&!InMenu&&!paused&&!mapVisible&&mode!="remote")Game.Tick(Time.fixedDeltaTime,inputs,new[]{false,mode=="solo"});}
        void OnApplicationFocus(bool focus){if(!focus&&!InMenu&&mode!="remote"&&Game.S.status=="playing"){paused=true;Capture(false);}}
        void OnDestroy(){Capture(false);if(font!=null)Destroy(font);if(customSkin!=null)Destroy(customSkin);}
        string Text(string en,string cn){return english?en:cn;}
        static string Clock(float t){int s=Mathf.Max(0,Mathf.CeilToInt(t));return (s/60).ToString("00")+":"+(s%60).ToString("00");}
        void Rect(float x,float y,float w,float h,Color c){Color previous=GUI.color;GUI.color=c;GUI.DrawTexture(new Rect(x,y,w,h),Texture2D.whiteTexture);GUI.color=previous;}
        void Label(float x,float y,float w,float h,string text,int size,Color color){GUIStyle style=new GUIStyle(GUI.skin.label);style.fontSize=size;style.normal.textColor=color;style.wordWrap=true;GUI.Label(new Rect(x,y,w,h),text,style);}
        bool Button(float x,float y,float w,float h,string label){return GUI.Button(new Rect(x,y,w,h),label);}
        void Panel(float x,float y,float w,float h){Rect(x,y,w,h,new Color(.035f,.065f,.055f,.95f));Rect(x,y,w,1,accent*.75f);}
        void OnGUI()
        {
            if(Game==null)return;if(customSkin==null){customSkin=Instantiate(GUI.skin);if(font!=null)customSkin.font=font;customSkin.label.normal.textColor=ink;customSkin.button.fontSize=16;customSkin.button.normal.textColor=ink;customSkin.textField.fontSize=17;}
            GUI.skin=customSkin;Matrix4x4 previous=GUI.matrix;GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,new Vector3(Screen.width/1280f,Screen.height/720f,1));
            if(InMenu)DrawMenu();else{DrawHud();if(Game.S.status!="playing")DrawResult();else if(mapVisible)DrawMap();else if(paused)DrawPause();}
            if(guideVisible)DrawGuide();GUI.matrix=previous;
        }
        void DrawMenu()
        {
            Rect(0,0,1280,720,new Color(.02f,.04f,.03f,.69f));Label(55,35,750,28,"T W I N   L A B Y R I N T H   /   UNITY GEOMETRY EDITION",16,accent);
            Label(80,190,520,90,Text("TWIN","双生"),65,ink);Label(145,277,500,85,Text("LABYRINTH","迷城"),65,ink);
            Label(85,405,580,80,Text("The weather rewrites the rules.\nBoth of you must make it out.","天气会改变规则。\n记住，两个人都要到。"),24,accent);
            Label(85,530,540,40,Text("Solid geometry. Real depth. No image textures.","纯几何建模 · 三维光影 · 无图片贴图"),16,ink);
            Panel(720,123,510,545);Label(745,140,440,36,Text("CHOOSE YOUR PARTNER","选择你的共生体"),19,accent);
            string[] modes={"solo","local","remote"};string[] names={Text("Solo + AI","单人 + AI"),Text("Local split","本地分屏"),Text("Online","远程房间")};
            for(int i=0;i<3;i++){if(mode==modes[i])Rect(745+i*153,182,144,43,new Color(.22f,.35f,.27f));if(Button(745+i*153,182,144,43,names[i])){network.Leave();mode=modes[i];}}
            Label(745,238,140,26,Text("Difficulty","世界难度"),16,ink);string[] diffs={"easy","normal","hard"};string[] dn={Text("Easy","简单"),Text("Normal","中等"),Text("Hard","困难")};for(int i=0;i<3;i++)if(Button(860+i*111,234,105,34,(difficulty==diffs[i]?"• ":"")+dn[i]))difficulty=diffs[i];
            Label(745,281,130,26,Text("AI partner","队友段位"),16,ink);string[] ais={"rookie","veteran","elite"};string[] an={Text("Rookie","新手"),Text("Veteran","老兵"),Text("Elite","精英")};for(int i=0;i<3;i++)if(Button(860+i*111,277,105,34,(ai==ais[i]?"• ":"")+an[i]))ai=ais[i];
            Label(745,327,145,26,Text("Sensitivity","视角灵敏度"),15,ink);sensitivity=GUI.HorizontalSlider(new Rect(900,337,285,20),sensitivity,.2f,2.2f);
            Label(745,363,140,26,Text("Brightness","环境亮度"),15,ink);brightness=GUI.HorizontalSlider(new Rect(900,373,285,20),brightness,.65f,1.8f);
            Label(745,399,120,25,Text("Music","音乐"),15,ink);sound.MusicVolume=GUI.HorizontalSlider(new Rect(822,407,128,18),sound.MusicVolume,0,1);Label(974,399,70,25,Text("Effects","音效"),15,ink);sound.EffectsVolume=GUI.HorizontalSlider(new Rect(1055,407,128,18),sound.EffectsVolume,0,1);
            if(mode=="remote"){
                serverUrl=GUI.TextField(new Rect(745,440,440,32),serverUrl);roomCode=GUI.TextField(new Rect(745,480,105,34),roomCode,4);GUI.enabled=!network.Busy&&!network.Connected;
                if(Button(864,480,155,34,Text("Create room","创建房间"))){network.ServerUrl=serverUrl;network.Create(difficulty,ai);}if(Button(1030,480,155,34,Text("Join room","加入房间"))){network.ServerUrl=serverUrl;network.Join(roomCode);}GUI.enabled=true;
                Label(745,525,445,76,network.Message,14,accent);if(network.Connected&&Button(745,601,440,36,Text("Copy invite address + code","复制服务器地址与房间码")))GUIUtility.systemCopyBuffer=serverUrl+" | "+network.Code;
            }else{if(Button(745,458,440,58,Text("ENTER THE BUILDING  →","进入迷城  →")))BeginLocal();if(Button(745,536,214,35,Text("Survival notes","入楼须知")))guideVisible=true;if(Button(971,536,214,35,Text("Test audio","试听音效")))sound.Preview();
                Label(745,591,440,52,Text("WASD + mouse / Q E · J to swing\nP pause · M map · N music · T restart","WASD + 鼠标 / Q E · J 挥刀\nP 暂停 · M 地图 · N 音乐 · T 重开"),14,ink);}
            if(Button(1065,32,145,32,english?"中文":"English"))english=!english;
        }
        void DrawHud()
        {
            GameState s=Game.S;int role=mode=="remote"?network.Role:0;Player p=s.players[role];Panel(22,17,1236,106);
            Label(42,28,170,22,Text("BUILDING TIMER","建筑爆破"),13,accent);Label(42,53,180,47,Clock(s.bomb),34,s.bomb<30?Color.red:ink);
            string weatherName=english?Game.CurrentWeather.id.ToUpperInvariant():Game.CurrentWeather.name;
            Label(245,28,270,30,(s.exitOpen?Text("EXIT OPEN","出口开启"):weatherName)+"   "+(s.exitOpen?"":Mathf.CeilToInt(s.left)+"s"),23,accent);
            Label(245,63,770,24,Text(EnglishRule(Game.CurrentWeather.id),Game.CurrentWeather.rule),16,ink);
            string next=s.stage<4?(english?Weather.All[s.order[s.stage+1]].id:Weather.All[s.order[s.stage+1]].name):Text("EXIT","出口");Label(245,90,750,24,Text("Next: ","下一段：")+next,13,s.left<15?new Color(1,.5f,.3f):ink);
            Label(1060,30,180,30,Text("Armor ","复活甲 ")+s.armor,17,ink);Label(1060,62,180,50,mode=="remote"?(role==0?"A / ":"B / ")+network.Code+"\n"+network.Latency+" ms"+(network.Bot?" · AI":""):difficulty+" / "+(Math.Min(5,s.stage+1))+" of 5",13,accent);
            string warning="";if(s.poison>0)warning+=Text("B POISONED: ","B 中毒：")+Mathf.CeilToInt(s.poison)+"s  ";Room room=Game.RoomAt(p.x,p.y);if(p.exposure>1)warning+=Text("EXPOSURE: ","雷击暴露：")+p.exposure.ToString("0.0")+"s  ";foreach(Room r in s.rooms)if(r.blast>0)warning+=Text("ROOM ","房间 ")+(r.id+1)+" · "+Mathf.Max(0,Game.D.blast-r.blast).ToString("0.0")+"s ! ";
            if(warning!=""){Rect(240,138,800,40,new Color(.3f,.025f,.01f,.8f));Label(253,144,775,30,warning,18,new Color(1,.65f,.43f));}
            if(s.events.Count>0){GameEvent e=s.events[s.events.Count-1];if(s.t-e.t<3.2f){Panel(325,590,630,45);Label(340,600,605,35,english?EnglishEvent(e):e.text,16,ink);}}
            Label(25,678,450,27,(room==null?Text("CORRIDOR","走廊"):Text("ROOM ","房间 ")+(room.id+1).ToString("00")+(room.sacred?" / SANCTUM":"")),15,ink);
            Label(475,678,550,27,s.exitOpen?Text("Meet at room 24 — both players.","前往 24 号出口，两人都要到。"):Text("Survive all five weather stages.","历尽五种天气，出口才会开启。"),14,accent);
            Label(1010,678,230,27,"P / ESC  ·  M MAP",14,ink);
            Label(mode=="local"?312:632,347,22,28,"+",20,ink);if(mode=="local")Label(952,347,22,28,"+",20,ink);
        }
        string EnglishRule(string id){switch(id){case "rain":return "Leave corridors before lightning strikes. Rooms provide shelter.";case "fog":return "Blue armband: partner. Violet armband: impostor.";case "blood":return "B is poisoned. A must strike B at close range to cure them.";case "sand":return "Two lives in a room trigger a blast. Corpses count for 3 seconds.";default:return "Read the door signs. Do not harm your partner.";}}
        string EnglishEvent(GameEvent e){switch(e.type){case "weather":return Game.S.exitOpen?"Exit open. Both of you must arrive.":EnglishRule(Game.CurrentWeather.id);case "cure":return "Blood pact cured. Your partner is alive.";case "hurt":return "Revival armor shattered. Be careful.";case "blast":return "Room collapsed.";case "fake":return "Impostor revealed.";case "kill":return "A life was recorded in the ledger.";case "swing":return "Missed.";default:return "Room entered. Building timer reset.";}}
        void DrawPause(){Panel(360,185,560,375);Label(390,208,510,55,Text("THE BUILDING HOLDS ITS BREATH","楼，暂时屏住了呼吸。"),25,ink);Label(390,270,500,56,mode=="remote"?Text("Online games keep running. Return to your partner.","联机世界继续运行，请尽快回到队友身边。"):Text("Rest. Then continue together.","休息好了，就继续同行。"),17,accent);
            if(Button(390,337,500,44,Text("Resume","继续同行")))Pause();if(mode!="remote"&&Button(390,391,500,44,Text("Restart","重新开始")))BeginLocal();if(Button(390,447,500,44,Text("Back to entrance","返回入口")))Menu();}
        void DrawResult(){GameState s=Game.S;Panel(350,145,580,465);Label(382,168,515,62,s.status=="won"?Text("BOTH OF YOU MADE IT.","两个人，都回来了。"):Text("THE BUILDING REMEMBERS.","楼又安静了下来。"),28,ink);
            Label(382,240,515,55,english?(s.status=="won"?"Both players reached the exit.":"One life was lost. Weather: "+Game.CurrentWeather.id+". Check the survival rules."):s.reason,17,accent);
            Label(382,304,515,53,s.rank+"   /   "+Clock(s.t)+Text("   Armor used: ","   复活甲消耗：")+s.used,27,ink);
            Label(382,373,515,65,Text("LEDGER  /  killers: ","账簿 / 杀手：")+s.kills.killer+Text("   impostors: ","   伪装：")+s.kills.fake+Text("   innocent: ","   无辜：")+s.kills.innocent+"\n"+(english?"":string.Join(" / ",s.titles.ToArray())),16,ink);
            if(Time.unscaledTime<noticeUntil)Label(382,435,510,25,notice,15,accent);
            if(Button(382,479,515,45,mode=="remote"?(ready?Text("Waiting for partner…","等待对方准备…"):Text("Ready — swap roles next round","准备再战，下一局交换角色")):Text("Try again","再来一局"))){if(mode=="remote"){ready=network.Ready();}else BeginLocal();}
            if(Button(382,541,515,40,Text("Back to entrance","返回入口")))Menu();}
        void DrawMap(){Panel(235,135,810,515);Label(260,152,650,30,Text("FLOOR PLAN / door signs are truthful","楼层平面 / 门牌不会说谎"),20,accent);float scale=13;float ox=320,oy=194;
            for(int y=0;y<Game.World.h;y++)for(int x=0;x<Game.World.w;x++)if(!Game.Wall(x+.5f,y+.5f))Rect(ox+x*scale,oy+y*scale,scale-.5f,scale-.5f,new Color(.16f,.25f,.19f));
            foreach(Room r in Game.S.rooms){Color c=r.sacred?new Color(.3f,.46f,.3f):!r.known?new Color(.27f,.3f,.28f):r.killer?new Color(.46f,.25f,.2f):new Color(.22f,.36f,.24f);Rect(ox+r.x1*scale,oy+r.y1*scale,(r.x2-r.x1+1)*scale,(r.y2-r.y1+1)*scale,c);Label(ox+(r.cx-1)*scale,oy+(r.cy-.6f)*scale,65,30,(r.id+1).ToString("00")+(r.id==23?" EXIT":""),12,ink);}
            for(int i=0;i<2;i++){Player p=Game.S.players[i];Label(ox+p.x*scale-6,oy+p.y*scale-12,25,30,i==0?"A":"B",19,Color.cyan);}if(Button(929,148,90,31,"M / X")){mapVisible=false;Capture(!paused);}}
        void DrawGuide(){Panel(265,105,750,530);Label(295,129,680,40,Text("SURVIVAL NOTES","入楼须知"),25,accent);string[] lines={Text("CLEAR: read signs; accidental partner kills cost armor.","晴空：读门牌；误伤同伴会消耗复活甲。"),Text("RAIN: corridors are exposed; rooms shelter you.","雷雨：走廊视为露天，进入房间避雷。"),Text("FOG: violet armband is fake; blue is your partner.","浓雾：紫色腕环是假队友，蓝色腕环是真队友。"),Text("BLOOD: A must strike poisoned B to cure them.","血月：A 必须近距离挥刀替中毒的 B 解毒。"),Text("SAND: two lives + player in a room cause a blast.","沙暴：房内有玩家且有两条命便会引爆。尸体计数 3 秒。"),Text("Rooms 01 and 24 never explode. Both must reach 24.","01 和 24 号祝圣房不引爆；两人同时到出口才算赢。"),Text("P2: arrows move/turn, Enter attack, comma/period look.","本地 P2：方向键移动转向，回车挥刀，逗号/句点俯仰。")};for(int i=0;i<lines.Length;i++)Label(295,189+i*49,685,45,lines[i],17,ink);if(Button(295,563,685,43,Text("Understood","记住了，两个人都要到")))guideVisible=false;}
    }
}
