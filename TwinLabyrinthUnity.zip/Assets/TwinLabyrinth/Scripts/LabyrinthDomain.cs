using System;
using System.Collections.Generic;

namespace TwinLabyrinth
{
    [Serializable] public class Body { public float x, y, a, pitch; public bool alive = true; }
    [Serializable] public class Player : Body
    {
        public float inv = 2, exposure, attack; public int room;
        [NonSerialized] public float routeAt; [NonSerialized] public Point way;
    }
    [Serializable] public class Npc : Body
    {
        public int id, home; public string kind = "resident";
        public float deadAt = -99, wind, phase, grace; public bool harmless;
    }
    [Serializable] public class Room
    {
        public int id, cx, cy, x1, y1, x2, y2;
        public bool sacred, known, killer, ruined; public float blast;
    }
    [Serializable] public class KillLedger { public int killer, fake, innocent, sand; }
    [Serializable] public class Tutorial { public bool move, attack, room, sign, weather; }
    [Serializable] public class GameEvent { public int id; public string text, type; public float t; }
    [Serializable] public class WorldData { public int w = 49, h = 33; public int[] cells; }
    [Serializable] public class GameState
    {
        public int seed, armor, used, stage, eventId, fakes, score;
        public string difficulty = "normal", mode = "solo", ai = "elite", status = "playing", reason = "", rank = "";
        public Player[] players; public List<Npc> npcs = new List<Npc>(); public Room[] rooms;
        public int[] order = {0, 1, 2, 3, 4}; public float t, bomb, left, poison;
        public bool cured, exitOpen; public KillLedger kills = new KillLedger();
        public Tutorial tutorial = new Tutorial(); public List<GameEvent> events = new List<GameEvent>();
        public List<string> titles = new List<string>();
    }
    [Serializable] public class PlayerInput { public float forward, strafe, turn, pitch; public bool attack; }
    public class Point { public float x, y; public Point(float x, float y) { this.x = x; this.y = y; } }
    public class Difficulty
    {
        public int armor, bomb, lightning, poison, fakes, density;
        public float blast, reveal, killer, scale;
        public static Difficulty Get(string key)
        {
            if (key == "easy") return new Difficulty {armor=2,bomb=240,lightning=15,poison=60,blast=2.5f,reveal=.8f,killer=.25f,fakes=1,density=2,scale=1.2f};
            if (key == "hard") return new Difficulty {armor=0,bomb=135,lightning=7,poison=35,blast=1,reveal=.4f,killer=.55f,fakes=3,density=4,scale=.85f};
            return new Difficulty {armor=1,bomb=180,lightning=10,poison=46,blast=1.5f,reveal=.6f,killer=.4f,fakes=2,density=3,scale=1};
        }
    }
    public class Weather
    {
        public string id, name, rule; public int duration;
        public static readonly Weather[] All = {
            new Weather {id="clear",name="晴空",duration=40,rule="读懂门牌，寻找出口。不要伤害同伴。"},
            new Weather {id="rain",name="雷雨",duration=55,rule="走廊暴露过久会遭雷击。进入房间避难。"},
            new Weather {id="fog",name="浓雾",duration=55,rule="紫色腕环是假队友。靠近后及时识破。"},
            new Weather {id="blood",name="血月",duration=60,rule="B 中毒，必须由 A 在近距离挥刀解毒。"},
            new Weather {id="sand",name="沙暴",duration=50,rule="房内两条命就会引爆。尸体仍计数 3 秒。"}
        };
    }
    public class SeedRandom
    {
        uint a;
        public SeedRandom(int seed) { a = (uint)seed; }
        public double Next()
        {
            unchecked { a += 0x6D2B79F5; uint t = (a ^ (a >> 15)) * (a | 1);
                t ^= t + ((t ^ (t >> 7)) * (t | 61)); return (t ^ (t >> 14)) / 4294967296.0; }
        }
    }
    // This core deliberately has no Unity dependency. It also runs in the console smoke tests.
    public class LabyrinthGame
    {
        public GameState S; public WorldData World; public Difficulty D;
        public Weather CurrentWeather { get { return Weather.All[S.stage < 5 ? S.order[S.stage] : 0]; } }
        static float Sin(float x) { return (float)Math.Sin(x); }
        static float Cos(float x) { return (float)Math.Cos(x); }
        static float Atan(float y,float x) { return (float)Math.Atan2(y,x); }
        public static float Clamp(float v,float a,float b) { return Math.Max(a,Math.Min(b,v)); }
        public static float Distance(float x,float y,float x2,float y2) { return (float)Math.Sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2)); }
        public static float Distance(Body a,Body b) { return Distance(a.x,a.y,b.x,b.y); }
        public LabyrinthGame(int seed,string difficulty,string mode,string ai)
        {
            D=Difficulty.Get(difficulty); S=new GameState {seed=seed,difficulty=difficulty,mode=mode,ai=ai,armor=D.armor,bomb=D.bomb};
            Generate(seed); S.players=new[] {new Player {x=3.3f,y=4},new Player {x=5,y=4.6f}};
            foreach(Player p in S.players) p.a=Wall(8.5f,4.5f)?(float)Math.PI/2:0;
            SeedRandom rand=new SeedRandom(seed+99); for(int i=4;i>0;i--) {int j=(int)(rand.Next()*(i+1));int t=S.order[i];S.order[i]=S.order[j];S.order[j]=t;}
            S.left=CurrentWeather.duration*D.scale; EnterWeather();
        }
        public void Load(GameState state,WorldData world) { S=state;D=Difficulty.Get(S.difficulty);if(world!=null&&world.cells!=null)World=world; }
        void Generate(int seed)
        {
            SeedRandom rand=new SeedRandom(seed);World=new WorldData {cells=new int[49*33]};for(int i=0;i<World.cells.Length;i++)World.cells[i]=1;
            S.rooms=new Room[24];for(int ry=0;ry<4;ry++)for(int rx=0;rx<6;rx++) {
                int id=ry*6+rx,cx=rx*8+4,cy=ry*8+4,half=rand.Next()<.35?2:3;
                Room r=new Room {id=id,cx=cx,cy=cy,x1=cx-half,y1=cy-half,x2=cx+half-1,y2=cy+half-1,sacred=id==0||id==23,known=rand.Next()<D.reveal};
                if(r.sacred)r.known=true;S.rooms[id]=r;for(int y=r.y1;y<=r.y2;y++)for(int x=r.x1;x<=r.x2;x++)SetCell(x,y,0);
            }
            HashSet<int> seen=new HashSet<int>();seen.Add(0);List<int> stack=new List<int>();stack.Add(0);List<int[]> edges=new List<int[]>();
            while(stack.Count>0) {int i=stack[stack.Count-1],rx=i%6,ry=i/6;List<int> ns=new List<int>();
                if(rx>0&&!seen.Contains(i-1))ns.Add(i-1);if(rx<5&&!seen.Contains(i+1))ns.Add(i+1);
                if(ry>0&&!seen.Contains(i-6))ns.Add(i-6);if(ry<3&&!seen.Contains(i+6))ns.Add(i+6);
                if(ns.Count==0){stack.RemoveAt(stack.Count-1);continue;}int n=ns[(int)(rand.Next()*ns.Count)];seen.Add(n);stack.Add(n);edges.Add(new[]{i,n});
            }
            for(int i=0;i<24;i++){if(i%6<5&&rand.Next()<.22)edges.Add(new[]{i,i+1});if(i<18&&rand.Next()<.22)edges.Add(new[]{i,i+6});}
            foreach(int[] edge in edges){Room a=S.rooms[edge[0]],b=S.rooms[edge[1]];for(int y=Math.Min(a.cy,b.cy);y<=Math.Max(a.cy,b.cy);y++)for(int x=Math.Min(a.cx,b.cx);x<=Math.Max(a.cx,b.cx);x++){SetCell(x,y,0);if(a.cy==b.cy)SetCell(x,y+1,0);else SetCell(x+1,y,0);}}
            foreach(Room r in S.rooms){if(r.sacred)continue;r.killer=rand.Next()<D.killer;int count=(int)(rand.Next()*(D.density+1));if(r.killer)count=Math.Max(1,count);
                for(int i=0;i<count;i++){Npc n=new Npc {id=S.npcs.Count,x=r.cx+(float)(rand.Next()-.5)*2.5f,y=r.cy+(float)(rand.Next()-.5)*2.5f,home=r.id};
                    n.kind=i==0&&r.killer?"killer":rand.Next()<.13?"wounded":"resident";n.phase=(float)rand.Next()*6.28f;S.npcs.Add(n);}}
        }
        void SetCell(int x,int y,int value){World.cells[y*World.w+x]=value;}
        public bool Wall(float x,float y){int ix=(int)Math.Floor(x),iy=(int)Math.Floor(y);return ix<0||iy<0||ix>=World.w||iy>=World.h||World.cells[iy*World.w+ix]!=0;}
        public Room RoomAt(float x,float y){foreach(Room r in S.rooms)if(x>=r.x1&&x<r.x2+1&&y>=r.y1&&y<r.y2+1)return r;return null;}
        public string RoomName(Body p){Room r=RoomAt(p.x,p.y);return r==null?"走廊":"房间 "+(r.id+1).ToString("00");}
        public bool LineOfSight(Body a,Body b){float d=Distance(a,b);for(float t=.15f;t<d;t+=.16f)if(Wall(a.x+(b.x-a.x)*t/d,a.y+(b.y-a.y)*t/d))return false;return true;}
        public void Move(Body p,float dx,float dy){const float r=.2f;float x=p.x+dx,y=p.y+dy;
            if(!Wall(x-r,p.y-r)&&!Wall(x+r,p.y-r)&&!Wall(x-r,p.y+r)&&!Wall(x+r,p.y+r))p.x=x;
            if(!Wall(p.x-r,y-r)&&!Wall(p.x+r,y-r)&&!Wall(p.x-r,y+r)&&!Wall(p.x+r,y+r))p.y=y;}
        public void Event(string text,string type){S.events.Add(new GameEvent {id=++S.eventId,text=text,type=type,t=S.t});if(S.events.Count>8)S.events.RemoveAt(0);}
        public void EnterWeather(){Weather w=CurrentWeather;Event(w.name+" · "+w.rule,"weather");if(w.id=="blood")S.poison=D.poison;
            if(w.id=="fog")for(int i=0;i<D.fakes;i++){Point p=FreeNear(S.players[0],2+i);S.npcs.Add(new Npc {id=S.npcs.Count,x=p.x,y=p.y,home=0,kind="fake",phase=i,harmless=i==0&&!S.tutorial.weather,grace=i==0&&!S.tutorial.weather?6:2});S.fakes++;}
            foreach(Room r in S.rooms)r.blast=0;}
        Point FreeNear(Body p,float radius){for(int i=0;i<24;i++){float a=i*(float)Math.PI/12,x=p.x+Cos(a)*radius,y=p.y+Sin(a)*radius;if(!Wall(x,y))return new Point(x,y);}return new Point(p.x+.4f,p.y+.4f);}
        public void Hurt(List<int> ids,string cause){List<int> hit=new List<int>();foreach(int id in ids)if(!hit.Contains(id)&&S.players[id].inv<=0)hit.Add(id);if(hit.Count==0)return;
            if(S.armor>0){S.armor--;S.used++;foreach(int id in hit){S.players[id].inv=3;S.players[id].exposure=0;}Event("复活甲碎裂 · "+cause,"hurt");if(cause.Contains("毒发"))S.poison=12;}
            else {foreach(int id in hit)S.players[id].alive=false;Finish(false,cause);}}
        public void Finish(bool win,string reason){if(S.status!="playing")return;S.status=win?"won":"lost";S.reason=reason;
            S.score=(int)Clamp((float)Math.Round(100-Math.Max(0,S.t-260)*.08-S.used*18+S.kills.fake*5+(S.used==0?10:0)),0,120);
            S.rank=win?(S.score>=100?"S":S.score>=80?"A":S.score>=60?"B":"C"):"—";S.titles.Clear();
            if(win&&S.kills.innocent==0)S.titles.Add("双生的黎明");if(win&&S.kills.fake==S.fakes&&S.fakes>0)S.titles.Add("夜雾判官");
            if(win&&S.kills.innocent>=3)S.titles.Add("屠夫");if(S.cured&&S.used==0)S.titles.Add("血契");if(S.mode=="solo"&&!S.players[1].alive)S.titles.Add("孤坟");}
        bool InBlade(Player p,Body target){float a=Atan(target.y-p.y,target.x-p.x)-p.a;a=Atan(Sin(a),Cos(a));return Distance(p,target)<1.8f&&Math.Abs(a)<.65f&&LineOfSight(p,target);}
        public void Attack(int i){if(S.status!="playing")return;Player p=S.players[i];if(p.attack>0)return;if(i==1&&S.mode=="remote")return;
            p.attack=.48f;S.tutorial.attack=true;Body closest=null;float near=99;foreach(Npc n in S.npcs)if(n.alive&&InBlade(p,n)&&Distance(p,n)<near){closest=n;near=Distance(p,n);}
            Player partner=S.players[1-i];if(InBlade(p,partner)&&Distance(p,partner)<near)closest=partner;
            if(closest==null){Event("挥空","swing");return;}if(closest==partner){if(CurrentWeather.id=="blood"&&S.poison>0&&(i==0||S.mode=="local")){S.poison=0;S.cured=true;S.players[1].inv=3;Event("血契已解 · 那一刀，是拥抱的形状。","cure");}else Hurt(new List<int>{1-i},"误杀同伴 · "+CurrentWeather.name+" / "+RoomName(p));return;}
            Npc victim=(Npc)closest;victim.alive=false;victim.deadAt=S.t;if(victim.kind=="killer")S.kills.killer++;else if(victim.kind=="fake")S.kills.fake++;else S.kills.innocent++;
            if(CurrentWeather.id=="sand")S.kills.sand++;Event(victim.kind=="fake"?"伪装破碎 · 紫光熄灭":victim.kind=="killer"?"威胁已清除":"账簿记下了这条无辜的命",victim.kind=="fake"?"fake":"kill");}
        public Point PathStep(Body p,Point target){int sx=(int)Math.Floor(p.x),sy=(int)Math.Floor(p.y),tx=(int)Math.Floor(target.x),ty=(int)Math.Floor(target.y);if(sx==tx&&sy==ty)return target;
            int start=sy*World.w+sx,end=ty*World.w+tx;Queue<int> queue=new Queue<int>();Dictionary<int,int> prev=new Dictionary<int,int>();queue.Enqueue(start);prev[start]=-1;
            int[] dx={1,-1,0,0},dy={0,0,1,-1};while(queue.Count>0){int a=queue.Dequeue();if(a==end)break;int x=a%World.w,y=a/World.w;for(int j=0;j<4;j++){int nx=x+dx[j],ny=y+dy[j],k=ny*World.w+nx;if(!Wall(nx+.5f,ny+.5f)&&!prev.ContainsKey(k)){prev[k]=a;queue.Enqueue(k);}}}
            if(!prev.ContainsKey(end))return new Point(p.x,p.y);int step=end;while(prev[step]!=start&&prev[step]!=-1)step=prev[step];return new Point(step%World.w+.5f,step/World.w+.5f);}
        public void Bot(int i,float dt){Player p=S.players[i],other=S.players[1-i];Point target=new Point(other.x,other.y);bool follow=true;float speed=S.ai=="rookie"?1.65f:S.ai=="veteran"?2.5f:3.1f;Room r=RoomAt(p.x,p.y),or=RoomAt(other.x,other.y);
            if(CurrentWeather.id=="sand"&&(r==null||!r.sacred)){Room best=null;float bd=float.MaxValue;foreach(Room room in S.rooms){bool safe=room.sacred||(!room.ruined&&(or==null||room.id!=or.id));if(!room.sacred)foreach(Npc n in S.npcs){Room nr=RoomAt(n.x,n.y);if(n.kind!="fake"&&(n.alive||S.t-n.deadAt<3)&&nr!=null&&nr.id==room.id)safe=false;}float d=Distance(p.x,p.y,room.cx,room.cy);if(safe&&d<bd){best=room;bd=d;}}if(best!=null){target=new Point(best.cx,best.cy);follow=false;}}
            if(S.exitOpen&&or!=null&&or.id==23){target=new Point(44,28);follow=false;}if(S.poison>0&&CurrentWeather.id=="blood"){target=new Point(other.x,other.y);follow=true;}
            if(follow&&Distance(p,other)<(S.poison>0?.85f:1.65f)){p.a=Atan(other.y-p.y,other.x-p.x);if(i==0&&S.poison>0)Attack(0);return;}
            if(p.way==null||S.t-p.routeAt>.35f){p.way=PathStep(p,target);p.routeAt=S.t;}float len=Distance(p.x,p.y,p.way.x,p.way.y);if(len>.06f){p.a=Atan(p.way.y-p.y,p.way.x-p.x);Move(p,Cos(p.a)*Math.Min(speed*dt,len),Sin(p.a)*Math.Min(speed*dt,len));}}
        public void Tick(float dt,PlayerInput[] inputs,bool[] bots){if(S.status!="playing")return;dt=Clamp(dt,0,.1f);S.t+=dt;S.bomb-=dt;S.left-=dt;
            if(S.bomb<=0){Finish(false,"建筑爆破 · 太久没有任何人进入新房间");return;}
            if(S.left<=0&&!S.exitOpen){S.stage++;S.tutorial.weather=true;if(S.stage>=5){S.exitOpen=true;S.left=99999;Event("出口已开启 · 两个人都要到。","weather");}else{S.left=CurrentWeather.duration*D.scale;EnterWeather();}}
            for(int i=0;i<2;i++){Player p=S.players[i];PlayerInput v=inputs[i]??new PlayerInput();p.inv=Math.Max(0,p.inv-dt);p.attack=Math.Max(0,p.attack-dt);
                if(bots[i])Bot(i,dt);else{p.a+=v.turn*dt;p.pitch=Clamp(p.pitch+v.pitch*dt,-.6f,.6f);float f=Clamp(v.forward,-1,1),s=Clamp(v.strafe,-1,1),scale=Math.Max(1,Distance(0,0,f,s));Move(p,(Cos(p.a)*f-Sin(p.a)*s)*3.15f*dt/scale,(Sin(p.a)*f+Cos(p.a)*s)*3.15f*dt/scale);if(v.attack)Attack(i);if(f!=0||s!=0||v.turn!=0)S.tutorial.move=true;}
                Room r=RoomAt(p.x,p.y);int id=r==null?-1:r.id;if(id!=p.room&&id>=0){S.bomb=D.bomb;S.tutorial.room=true;Event((i==0?"A":"B")+" 进入 "+(id+1).ToString("00")+" 号房 · 爆破时钟重置","info");}p.room=id;if(r!=null&&r.known)S.tutorial.sign=true;
                if(CurrentWeather.id=="rain"&&r==null&&!(S.mode=="solo"&&i==1)){p.exposure+=dt;if(p.exposure>=D.lightning){p.exposure=0;Hurt(new List<int>{i},"雷击 · 走廊暴露超过 "+D.lightning+" 秒");}}else p.exposure=Math.Max(0,p.exposure-dt*4);
            }
            if(S.poison>0){S.poison-=dt;if(S.poison<=0){Hurt(new List<int>{1},"血月毒发 · 持刀者未及时解毒");if(S.status=="playing"&&S.poison<=0)S.poison=.01f;}}
            if(CurrentWeather.id=="sand")foreach(Room r in S.rooms){if(r.sacred||r.ruined)continue;List<int> ps=new List<int>();for(int i=0;i<2;i++)if(S.players[i].room==r.id)ps.Add(i);int count=ps.Count;foreach(Npc n in S.npcs){Room nr=RoomAt(n.x,n.y);if(n.kind!="fake"&&(n.alive||S.t-n.deadAt<3)&&nr!=null&&nr.id==r.id)count++;}
                if(ps.Count>0&&count>=2){r.blast+=dt;if(r.blast>=D.blast){r.ruined=true;r.blast=0;foreach(Npc n in S.npcs){Room nr=RoomAt(n.x,n.y);if(n.alive&&nr!=null&&nr.id==r.id){n.alive=false;n.deadAt=S.t;}}Hurt(ps,"沙暴人头引爆 · 房间 "+(r.id+1).ToString("00"));Event("房间 "+(r.id+1)+" 已坍塌","blast");}}else r.blast=0;}
            foreach(Npc n in S.npcs){if(!n.alive)continue;int target=0;if(S.mode!="solo"&&Distance(n,S.players[1])<Distance(n,S.players[0]))target=1;Player p=S.players[target];float len=Distance(n,p);
                if(n.kind=="killer"||n.kind=="fake"){n.grace=Math.Max(0,n.grace-dt);Room home=S.rooms[n.home];if(len<(n.kind=="fake"?9:7)&&LineOfSight(n,p)&&n.grace<=0){if(len>1.05f){n.a=Atan(p.y-n.y,p.x-n.x);float speed=n.kind=="fake"?1.2f:1.45f;Move(n,Cos(n.a)*dt*speed,Sin(n.a)*dt*speed);n.wind=0;}else{n.wind+=dt;if(n.wind>1.7f){if(n.harmless){Event("紫腕环伸出了手，又退了回去 · 这一次只是在试探。","fake");n.wind=0;n.grace=5;continue;}Hurt(new List<int>{target},(n.kind=="fake"?"假队友偷袭":"杀手处决")+" · "+RoomName(p));n.wind=0;}}}
                    else{n.wind=0;if(n.kind=="killer"&&Distance(n.x,n.y,home.cx,home.cy)>3){n.a=Atan(home.cy-n.y,home.cx-n.x);Move(n,Cos(n.a)*dt,Sin(n.a)*dt);}}}
                else if(n.kind!="wounded"){float a=S.t*.35f+n.phase;Room home=S.rooms[n.home];float tx=home.cx+Cos(a)*1.1f,ty=home.cy+Sin(a)*1.1f;n.a=Atan(ty-n.y,tx-n.x);Move(n,(tx-n.x)*dt*.25f,(ty-n.y)*dt*.25f);}}
            if(S.exitOpen&&S.players[0].room==23&&S.players[1].room==23&&S.players[0].alive&&S.players[1].alive)Finish(true,"两个人，都走出了楼。");
        }
    }
}
