using System;
using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace TwinLabyrinth
{
    [Serializable] public class NetworkRequest
    {
        public string code,token,difficulty,ai; public bool includeWorld;
        public PlayerInput input=new PlayerInput(); public LookDelta look=new LookDelta();
    }
    [Serializable] public class LookDelta {public float a,pitch;}
    [Serializable] public class NetworkReply
    {
        public string code,token,error;public int role;public bool bot,ok;
        public GameState state;public WorldData world;
    }
    public sealed class LabyrinthNetwork : MonoBehaviour
    {
        public string ServerUrl="http://localhost:8787",Code="",Token="",Message="";
        public int Role,Latency;public bool Connected,Busy,Bot;
        public Action<GameState,WorldData> Received;public PlayerInput Input=new PlayerInput();
        public LookDelta Look=new LookDelta();float nextSync;bool haveWorld;
        public void Create(string difficulty,string ai){if(!Busy)StartCoroutine(Open("create",new NetworkRequest {difficulty=difficulty,ai=ai}));}
        public void Join(string code){if(!Busy)StartCoroutine(Open("join",new NetworkRequest {code=code}));}
        IEnumerator Open(string route,NetworkRequest request)
        {
            Busy=true;Message="Connecting / 正在连接…";NetworkReply reply=null;
            yield return Post(route,request,r=>reply=r);Busy=false;
            if(reply==null)return;Token=reply.token;Code=reply.code;Role=reply.role;Connected=true;haveWorld=false;
            Message="Room / 房间 "+Code+" · waiting for partner / 等待队友";
        }
        void Update(){if(Connected&&!Busy&&Time.unscaledTime>=nextSync){nextSync=Time.unscaledTime+.09f;StartCoroutine(Sync());}}
        IEnumerator Sync()
        {
            Busy=true;float start=Time.realtimeSinceStartup;LookDelta sent=Look;Look=new LookDelta();
            NetworkReply reply=null;yield return Post("sync",new NetworkRequest {code=Code,token=Token,input=Input,look=sent,includeWorld=!haveWorld},r=>reply=r);Busy=false;
            if(!Connected)return;if(reply==null){Look.a+=sent.a;Look.pitch+=sent.pitch;return;}Role=reply.role;Latency=Mathf.RoundToInt((Time.realtimeSinceStartup-start)*1000);Bot=reply.bot;
            if(reply.world!=null&&reply.world.cells!=null)haveWorld=true;
            if(reply.state!=null){Message="Room "+Code+" · "+Latency+" ms"+(Bot?" · AI takeover":"");if(Received!=null)Received(reply.state,reply.world);}
        }
        public bool Ready(){if(!Connected||Busy)return false;StartCoroutine(ReadyRoutine());return true;}
        IEnumerator ReadyRoutine(){Busy=true;yield return Post("ready",new NetworkRequest {code=Code,token=Token},r=>{if(r!=null)Message="Ready / 已准备，等待对方";});Busy=false;haveWorld=false;}
        public void Leave(){if(Connected){NetworkRequest request=new NetworkRequest {code=Code,token=Token};Connected=false;StartCoroutine(Post("leave",request,r=>{}));}Token="";Code="";haveWorld=false;Look=new LookDelta();Input=new PlayerInput();}
        IEnumerator Post(string route,NetworkRequest body,Action<NetworkReply> done)
        {
            string baseUrl=ServerUrl.Trim().TrimEnd('/');Uri uri;
            if(!Uri.TryCreate(baseUrl,UriKind.Absolute,out uri)||(uri.Scheme!="http"&&uri.Scheme!="https")){Message="Enter an HTTP(S) server URL / 请输入服务器地址";done(null);yield break;}
            using(UnityWebRequest req=new UnityWebRequest(baseUrl+"/api/"+route,"POST")){
                req.uploadHandler=new UploadHandlerRaw(Encoding.UTF8.GetBytes(JsonUtility.ToJson(body)));req.downloadHandler=new DownloadHandlerBuffer();req.SetRequestHeader("Content-Type","application/json");req.timeout=5;
                yield return req.SendWebRequest();NetworkReply reply=null;
                try{reply=JsonUtility.FromJson<NetworkReply>(req.downloadHandler.text);}catch(Exception){ }
                if(req.result!=UnityWebRequest.Result.Success||reply==null){Message=reply!=null&&!string.IsNullOrEmpty(reply.error)?reply.error:"Connection interrupted / 连接中断；对方 4 秒后由 AI 接管";if(req.responseCode==403||req.responseCode==404)Connected=false;done(null);}
                else done(reply);
            }
        }
        void OnApplicationQuit(){Connected=false;}
    }
}
