using System;
using System.Collections.Generic;
using UnityEngine;

namespace TwinLabyrinth
{
    // Self-contained synthesis: environmental loops, footsteps, weapon/impact, warnings and musical cues.
    // All clips are generated in memory, so the project imports neither audio files nor third-party samples.
    public sealed class LabyrinthSound : MonoBehaviour
    {
        readonly Dictionary<string,AudioClip> clips=new Dictionary<string,AudioClip>();
        AudioSource effects,bed,music,spatial;string currentWeather="";float nextFoot,nextBreath,nextHeartbeat,nextThunder,nextDetail,nextTick,nextThreat;
        Vector3 lastPosition; bool positionKnown; int lastEvent; bool completed;
        public float MusicVolume=.35f,EffectsVolume=.7f;public bool MusicMuted;
        public float Flash {get;private set;}
        public bool Active {get;private set;}
        const int Rate=22050;
        void Awake()
        {
            effects=Source("Effects",false);bed=Source("Weather",true);music=Source("Music",true);spatial=Source("Spatial warning",false);spatial.spatialBlend=.75f;spatial.minDistance=1;spatial.maxDistance=15;spatial.rolloffMode=AudioRolloffMode.Linear;
            AudioReverbFilter reverb=effects.gameObject.AddComponent<AudioReverbFilter>();reverb.reverbPreset=AudioReverbPreset.StoneCorridor;
            foreach(string kind in new[]{"step","wetstep","breath","heartbeat","swing","impact","glass","armor","blast","thunder","tick","door","growl","cure","win","lose","clear","rain","fog","blood","sand","clearMusic","rainMusic","fogMusic","bloodMusic","sandMusic"})
                clips[kind]=Create(kind,kind.Contains("Music")?8:kind=="clear"||kind=="rain"||kind=="fog"||kind=="blood"||kind=="sand"?4:kind=="thunder"||kind=="blast"?2.8f:kind=="win"||kind=="lose"?3:kind=="breath"?1.7f:kind=="cure"?1.3f:kind=="glass"?1:kind=="growl"?.8f:.45f);
        }
        AudioSource Source(string name,bool loop){GameObject o=new GameObject(name);o.transform.SetParent(transform,false);AudioSource source=o.AddComponent<AudioSource>();source.playOnAwake=false;source.loop=loop;source.spatialBlend=0;return source;}
        static float Wave(float f,float t){return Mathf.Sin(2*Mathf.PI*f*t);}
        AudioClip Create(string kind,float length)
        {
            int count=Mathf.CeilToInt(Rate*length);float[] samples=new float[count];System.Random random=new System.Random(kind.GetHashCode());float brown=0;
            bool loop=kind.Contains("Music")||kind=="clear"||kind=="rain"||kind=="fog"||kind=="blood"||kind=="sand";
            for(int i=0;i<count;i++)
            {
                float t=i/(float)Rate,n=(float)(random.NextDouble()*2-1);brown=(brown+.035f*n)/1.035f;float v=0,e=Mathf.Exp(-t*12);
                switch(kind){
                    case "step":v=(brown*4+Wave(78-t*60,t)*.5f)*e;break;
                    case "wetstep":v=(brown*4+Wave(62,t)*.35f)*e+n*Mathf.Exp(-t*20)*.17f;break;
                    case "breath":v=brown*1.3f*Mathf.Pow(Mathf.Sin(Mathf.PI*t/length),2);break;
                    case "heartbeat":v=Wave(53,t)*(Mathf.Exp(-t*25)+(t>.19f?Mathf.Exp(-(t-.19f)*32)*.65f:0));break;
                    case "swing":v=n*Mathf.Sin(Mathf.PI*t/length)*Mathf.Exp(-t*12)*.55f;break;
                    case "impact":v=(brown*4+Wave(70-t*80,t)*.65f)*e+n*Mathf.Exp(-t*50)*.2f;break;
                    case "glass":case "armor":v=(Wave(727,t)+Wave(1357,t)*.7f+Wave(2231,t)*.4f)*Mathf.Exp(-t*6)*.28f+n*Mathf.Exp(-t*24)*.17f;break;
                    case "thunder":case "blast":v=(brown*5+Wave(43,t)*.3f)*Mathf.Exp(-t*1.8f)+n*Mathf.Exp(-t*25)*.24f;break;
                    case "tick":v=Wave(1450,t)*Mathf.Exp(-t*85)+n*Mathf.Exp(-t*100)*.25f;break;
                    case "door":v=Wave(440,t)*Mathf.Exp(-t*16)*.5f+Wave(660,t)*Mathf.Exp(-t*11)*.18f;break;
                    case "growl":v=(Wave(48,t)+Wave(95,t)*.5f+brown*3)*Mathf.Sin(Mathf.PI*t/length)*.4f;break;
                    case "cure":v=(Wave(220,t)+Wave(275,t)+Wave(330,t))*.2f*Mathf.Exp(-t*2);break;
                    case "win":v=(Wave(220,t)+Wave(277.18f,t)+Wave(329.63f,t))*.15f*Mathf.Sin(Mathf.PI*t/length);break;
                    case "lose":v=(Wave(55,t)+Wave(58.3f,t)*.65f)*.25f*Mathf.Sin(Mathf.PI*t/length);break;
                    case "clear":v=brown*.2f+Wave(43,t)*.02f;break;
                    case "rain":v=n*.15f+brown*.5f;break;
                    case "fog":v=brown*.45f*(.7f+.3f*Wave(.5f,t));break;
                    case "blood":v=brown*.12f+Wave(36,t)*.035f;break;
                    case "sand":v=(n*.07f+brown*1.3f)*(.7f+.25f*Wave(.25f,t));break;
                    case "clearMusic":float mt=t%4;v=(Wave(mt<2?440:554.365f,t)*.1f+Wave(880,t)*.035f)*Mathf.Exp(-mt*2);break;
                    case "rainMusic":v=(Wave(55,t)+Wave(82.5f,t))*.035f;break;
                    case "fogMusic":v=(Wave(123.5f,t)+Wave(125,t))*.04f;break;
                    case "bloodMusic":v=(Wave(36,t)*.1f+Wave(65.4f,t)*.04f)*(.6f+.4f*Wave(.5f,t));break;
                    case "sandMusic":v=Wave(73.5f,t)*.055f+Wave(110,t)*.023f;break;
                }
                float edge=loop?Mathf.Min(1,Mathf.Min(t,length-t)*45):Mathf.Min(1,t*180);samples[i]=Mathf.Clamp(v*edge*.6f,-.85f,.85f);
            }
            AudioClip clip=AudioClip.Create(kind,count,1,Rate,false);clip.SetData(samples,0);return clip;
        }
        public void Begin(){CancelInvoke();Flash=0;lastEvent=0;completed=false;currentWeather="";positionKnown=false;Active=true;effects.Stop();bed.Stop();music.Stop();}
        public void Stop(){Active=false;CancelInvoke();effects.Stop();spatial.Stop();bed.Stop();music.Stop();Flash=0;}
        public void Play(string key,float volume){AudioClip clip;if(clips.TryGetValue(key,out clip))effects.PlayOneShot(clip,volume);}
        public void Preview(){effects.volume=EffectsVolume;Play("wetstep",.6f);Invoke("PreviewKnife",.4f);}
        void PreviewKnife(){Play("swing",.6f);}
        void DelayedThunder(){if(Active)Play("thunder",.75f);}
        void WinCue(){Play("win",.7f);}
        void LoseCue(){Play("lose",.7f);}
        public void Tick(LabyrinthGame game,int role,bool paused)
        {
            if(!Active||game==null)return;float now=Time.unscaledTime;effects.volume=EffectsVolume;spatial.volume=EffectsVolume*.65f;music.volume=paused||MusicMuted?0:MusicVolume;bed.volume=paused?0:EffectsVolume;
            Flash=Mathf.Max(0,Flash-Time.unscaledDeltaTime*6);if(paused)return;GameState s=game.S;string w=game.CurrentWeather.id;
            if(s.status!="playing"){if(!completed){completed=true;bed.Stop();music.Stop();Invoke(s.status=="won"?"WinCue":"LoseCue",.8f);}return;}
            if(w!=currentWeather){currentWeather=w;bed.clip=clips[w];bed.Play();music.clip=clips[w+"Music"];music.Play();}
            foreach(GameEvent e in s.events)if(e.id>lastEvent){lastEvent=e.id;switch(e.type){case "weather":Play("growl",.4f);break;case "swing":Play("swing",.65f);break;case "kill":Play("impact",.8f);break;case "fake":Play("glass",.6f);break;case "hurt":Play("armor",.8f);Play("heartbeat",.5f);break;case "blast":Play("blast",.8f);Flash=.75f;break;case "cure":Play("impact",.5f);Play("cure",.7f);break;default:if(e.text.Contains("进入"))Play("door",.2f);break;}}
            Vector3 p=LabyrinthWorldView.Position(s.players[role]);bool moving=positionKnown&&(p-lastPosition).sqrMagnitude>.00005f;if(moving&&now>nextFoot){Play(w=="rain"?"wetstep":"step",.55f);nextFoot=now+.39f;}lastPosition=p;positionKnown=true;
            if(now>nextBreath){Play("breath",s.poison>0?.5f:.24f);nextBreath=now+(s.poison>0?2.1f:4.7f);}
            float danger=99;Npc closest=null;foreach(Npc n in s.npcs)if(n.alive&&(n.kind=="killer"||n.kind=="fake")){float d=LabyrinthGame.Distance(s.players[role],n);if(d<danger){danger=d;closest=n;}}
            bool stressed=s.poison>0||danger<3;if((stressed||w=="fog")&&now>nextHeartbeat){Play("heartbeat",stressed?.5f:.2f);nextHeartbeat=now+(s.poison>0?.65f:1.1f);}
            if(closest!=null&&closest.wind>.15f){music.volume=0;if(now>nextThreat){spatial.transform.position=LabyrinthWorldView.Position(closest)+Vector3.up;spatial.PlayOneShot(clips["growl"],.8f);nextThreat=now+1.8f;}}
            Room room=game.RoomAt(s.players[role].x,s.players[role].y);if(room!=null&&room.blast>0&&now>nextTick){Play("tick",.75f);nextTick=now+Mathf.Max(.08f,(game.D.blast-room.blast)*.2f);}
            if(w=="rain"&&now>nextThunder){Flash=.8f;Invoke("DelayedThunder",1);nextThunder=now+9+UnityEngine.Random.value*7;}
            if(now>nextDetail){Play("door",.1f);nextDetail=now+9+UnityEngine.Random.value*11;}
        }
        void OnDestroy(){foreach(AudioClip clip in clips.Values)Destroy(clip);}
    }
}
