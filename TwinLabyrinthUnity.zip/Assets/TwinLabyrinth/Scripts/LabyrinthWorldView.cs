using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace TwinLabyrinth
{
    // Every visible surface is a mesh and a solid-color material. No image textures, sprites or billboards.
    public sealed class LabyrinthWorldView : MonoBehaviour
    {
        public const float Unit = 1.35f;
        public Camera[] Cameras = new Camera[2];
        Transform scenery; readonly Dictionary<string,Material> materials=new Dictionary<string,Material>();
        readonly Dictionary<int,Model> npcs=new Dictionary<int,Model>();
        readonly List<Mesh> ownedMeshes=new List<Mesh>();
        Model[] players=new Model[2]; Transform[] weapons=new Transform[2];
        Light[] lamps=new Light[24]; Transform[] ruins=new Transform[24]; Transform[] portal;
        readonly List<Transform> weatherBits=new List<Transform>();
        readonly List<TextMesh> signs=new List<TextMesh>();
        Light sun; string weather=""; float brightness=1; LabyrinthGame current;
        struct Model { public Transform root, leftArm,rightArm,leftLeg,rightLeg,head; public Vector3 previous; }
        Material Mat(string key,Color color,float metallic=0,float emission=0)
        {
            Material found;if(materials.TryGetValue(key,out found))return found;
            Shader shader=Shader.Find("Standard");if(shader==null)shader=Shader.Find("Legacy Shaders/Diffuse");
            Material m=new Material(shader);m.name=key;m.color=color;
            if(m.HasProperty("_Metallic"))m.SetFloat("_Metallic",metallic);
            if(m.HasProperty("_Glossiness"))m.SetFloat("_Glossiness",metallic>0?.38f:.12f);
            if(emission>0){m.EnableKeyword("_EMISSION");m.SetColor("_EmissionColor",color*emission);}
            materials.Add(key,m);return m;
        }
        public static Vector3 Position(Body p) { return new Vector3(p.x*Unit,0,p.y*Unit); }
        static void Layer(Transform root,int layer){root.gameObject.layer=layer;foreach(Transform child in root)Layer(child,layer);}
        Transform Shape(string name,PrimitiveType type,Transform parent,Vector3 position,Vector3 scale,Material material)
        {
            GameObject o=GameObject.CreatePrimitive(type);o.name=name;o.transform.SetParent(parent,false);o.transform.localPosition=position;o.transform.localScale=scale;
            o.GetComponent<Renderer>().sharedMaterial=material;Collider collider=o.GetComponent<Collider>();if(collider!=null)Destroy(collider);return o.transform;
        }
        Transform Box(string name,Transform parent,Vector3 p,Vector3 size,Material m){return Shape(name,PrimitiveType.Cube,parent,p,size,m);}
        Transform Pivot(string name,Transform parent,Vector3 pos){GameObject o=new GameObject(name);o.transform.SetParent(parent,false);o.transform.localPosition=pos;return o.transform;}
        public void Build(LabyrinthGame game)
        {
            current=game;if(scenery!=null){scenery.gameObject.SetActive(false);Destroy(scenery.gameObject);}foreach(Mesh mesh in ownedMeshes)Destroy(mesh);ownedMeshes.Clear();
            scenery=Pivot("Procedural geometry",transform,Vector3.zero);npcs.Clear();weatherBits.Clear();signs.Clear();weather="";
            Material wall=Mat("Concrete",new Color(.28f,.32f,.29f)),wall2=Mat("Concrete variation",new Color(.33f,.35f,.3f));
            Material floor=Mat("Floor",new Color(.17f,.2f,.18f)),floor2=Mat("Floor variation",new Color(.2f,.22f,.19f));
            Material trim=Mat("Iron",new Color(.1f,.13f,.12f),.45f),ceiling=Mat("Ceiling",new Color(.22f,.25f,.22f));
            GeometryBatch walls=new GeometryBatch(),walls2=new GeometryBatch(),ground=new GeometryBatch(),ground2=new GeometryBatch(),trims=new GeometryBatch();
            for(int y=0;y<game.World.h;y++)for(int x=0;x<game.World.w;x++){
                Vector3 p=new Vector3((x+.5f)*Unit,1.45f,(y+.5f)*Unit);
                if(game.Wall(x+.5f,y+.5f)){bool exposed=!game.Wall(x-1+.5f,y+.5f)||!game.Wall(x+1+.5f,y+.5f)||!game.Wall(x+.5f,y-1+.5f)||!game.Wall(x+.5f,y+1+.5f);if(exposed){((x+y)%5==0?walls2:walls).Cube(p,new Vector3(Unit,2.9f,Unit));trims.Cube(new Vector3(p.x,.12f,p.z),new Vector3(Unit+.015f,.24f,Unit+.015f));}}
                else{((x+y)%4==0?ground2:ground).Cube(new Vector3(p.x,-.075f,p.z),new Vector3(Unit-.015f,.15f,Unit-.015f));}
            }
            Batch("Walls",walls,wall);Batch("Walls secondary",walls2,wall2);Batch("Skirting",trims,trim);Batch("Floor",ground,floor);Batch("Floor variation",ground2,floor2);
            foreach(Room r in game.S.rooms){Vector3 center=new Vector3(r.cx*Unit,0,r.cy*Unit);float width=(r.x2-r.x1+1)*Unit,depth=(r.y2-r.y1+1)*Unit;
                Box("Ceiling "+(r.id+1),scenery,center+Vector3.up*3.02f,new Vector3(width,.24f,depth),ceiling);
                Box("Light housing "+r.id,scenery,center+Vector3.up*2.83f,new Vector3(1.3f,.12f,.28f),trim);
                Box("Fluorescent mesh "+r.id,scenery,center+Vector3.up*2.75f,new Vector3(1.1f,.04f,.13f),Mat("Fluorescent",new Color(.76f,.85f,.72f),0,1.4f));
                Transform l=Pivot("Room light "+r.id,scenery,center+Vector3.up*2.45f);Light light=l.gameObject.AddComponent<Light>();light.type=LightType.Point;light.color=new Color(.77f,.86f,.72f);light.intensity=1.8f;light.range=width*.83f;light.shadows=LightShadows.None;lamps[r.id]=light;
                // Real doorway signs are positioned at each traversable room edge.
                for(int x=r.x1;x<=r.x2;x++){if(!game.Wall(x+.5f,r.y1-.5f))DoorSign(r,new Vector3((x+.5f)*Unit,2.27f,r.y1*Unit),0,trim);if(!game.Wall(x+.5f,r.y2+1.5f))DoorSign(r,new Vector3((x+.5f)*Unit,2.27f,(r.y2+1)*Unit),180,trim);}
                for(int y=r.y1;y<=r.y2;y++){if(!game.Wall(r.x1-.5f,y+.5f))DoorSign(r,new Vector3(r.x1*Unit,2.27f,(y+.5f)*Unit),90,trim);if(!game.Wall(r.x2+1.5f,y+.5f))DoorSign(r,new Vector3((r.x2+1)*Unit,2.27f,(y+.5f)*Unit),270,trim);}
                Transform rubble=Pivot("Collapse debris "+r.id,scenery,center);ruins[r.id]=rubble;for(int j=0;j<6;j++){float a=j*1.7f;Transform b=Box("Concrete chunk",rubble,new Vector3(Mathf.Cos(a)*1.1f,.12f,Mathf.Sin(a)*1.1f),new Vector3(.32f,.2f,.4f),wall2);b.localRotation=Quaternion.Euler(j*11,j*37,12);}rubble.gameObject.SetActive(false);
                // Sparse geometric props decorate the perimeter and never change pathfinding.
                if(!r.sacred&&r.id%3==0){Vector3 pos=new Vector3((r.x1+.38f)*Unit,.4f,(r.y1+.38f)*Unit);Box("Utility box",scenery,pos,new Vector3(.42f,.8f,.3f),trim);}
            }
            Room exit=game.S.rooms[23];Transform portalRoot=Pivot("Exit arch",scenery,new Vector3(exit.cx*Unit,0,exit.cy*Unit));portal=new Transform[3];Material exitMat=Mat("Exit dormant",new Color(.34f,.4f,.32f),.1f);
            portal[0]=Box("Left pillar",portalRoot,new Vector3(-.85f,1.1f,0),new Vector3(.18f,2.2f,.24f),exitMat);portal[1]=Box("Right pillar",portalRoot,new Vector3(.85f,1.1f,0),new Vector3(.18f,2.2f,.24f),exitMat);portal[2]=Box("Lintel",portalRoot,new Vector3(0,2.15f,0),new Vector3(1.85f,.18f,.24f),exitMat);
            for(int i=0;i<2;i++){players[i]=Human("Player "+i,"buddy",scenery);Layer(players[i].root,8+i);if(Cameras[i]==null){Transform rig=Pivot("Camera "+i,transform,Vector3.zero);Cameras[i]=rig.gameObject.AddComponent<Camera>();Cameras[i].fieldOfView=73;Cameras[i].nearClipPlane=.04f;Cameras[i].farClipPlane=90;Cameras[i].clearFlags=CameraClearFlags.SolidColor;rig.gameObject.AddComponent<AudioListener>();
                    Transform torch=Pivot("Flashlight",rig,new Vector3(.1f,.08f,.14f));Light light=torch.gameObject.AddComponent<Light>();light.type=LightType.Spot;light.color=new Color(1,.89f,.68f);light.intensity=2.7f;light.spotAngle=78;light.range=18;light.shadows=LightShadows.Soft;light.shadowStrength=.65f;
                    weapons[i]=Cleaver(rig,new Vector3(.4f,-.35f,.56f));Layer(weapons[i],10+i);}
                Cameras[i].cullingMask=~((1<<(8+i))|(1<<(10+1-i)));}
            if(sun==null){Transform st=Pivot("Moonlight",transform,Vector3.zero);sun=st.gameObject.AddComponent<Light>();sun.type=LightType.Directional;st.rotation=Quaternion.Euler(58,-40,0);sun.shadows=LightShadows.Soft;sun.intensity=.35f;}
            for(int i=0;i<64;i++){Transform bit=Box("Weather particle",scenery,Vector3.zero,new Vector3(.012f,.16f,.012f),Mat("Rain",new Color(.45f,.57f,.57f),0,.25f));bit.gameObject.SetActive(false);weatherBits.Add(bit);}
            QualitySettings.shadowDistance=22;QualitySettings.pixelLightCount=4;RenderSettings.ambientMode=AmbientMode.Flat;RenderSettings.fog=true;RenderSettings.fogMode=FogMode.ExponentialSquared;
        }
        void DoorSign(Room r,Vector3 pos,float rotation,Material trim)
        {
            Transform root=Pivot("Door sign "+(r.id+1),scenery,pos);root.localRotation=Quaternion.Euler(0,rotation,0);
            Box("Sign plate",root,Vector3.zero,new Vector3(.94f,.32f,.07f),trim);
            Color color=r.sacred?new Color(.64f,.8f,.48f):!r.known?new Color(.58f,.6f,.56f):r.killer?new Color(.88f,.36f,.23f):new Color(.35f,.74f,.47f);
            Box("Status light",root,new Vector3(-.38f,0,-.045f),new Vector3(.055f,.2f,.02f),Mat("Sign "+color.ToString(),color,0,.8f));
            string label=(r.id+1).ToString("00")+" "+(r.id==23?"EXIT":r.sacred?"SANCTUM":!r.known?"UNKNOWN":r.killer?"DANGER":"SAFE");
            for(int side=0;side<2;side++){Transform t=Pivot("Label",root,new Vector3(.02f,0,side==0?-.044f:.044f));t.localRotation=Quaternion.Euler(0,side==0?180:0,0);TextMesh text=t.gameObject.AddComponent<TextMesh>();text.text=label;text.anchor=TextAnchor.MiddleCenter;text.alignment=TextAlignment.Center;text.fontSize=40;text.characterSize=.038f;text.color=color;signs.Add(text);}
        }
        Model Human(string name,string kind,Transform parent)
        {
            Model model=new Model();model.root=Pivot(name,parent,Vector3.zero);
            bool killer=kind=="killer",fake=kind=="fake",buddy=kind=="buddy"||fake;
            Material cloth=Mat(killer?"Killer coat":buddy?"Green jacket":"Resident coat",killer?new Color(.11f,.14f,.13f):buddy?new Color(.17f,.3f,.25f):new Color(.42f,.37f,.28f));
            Material skin=Mat("Skin",new Color(.61f,.56f,.43f)),black=Mat("Boots",new Color(.085f,.1f,.095f));
            Box("Torso",model.root,new Vector3(0,1.11f,0),new Vector3(.46f,.62f,.26f),cloth);
            Shape("Neck",PrimitiveType.Cylinder,model.root,new Vector3(0,1.48f,0),new Vector3(.1f,.065f,.1f),skin);
            model.head=Box("Head",model.root,new Vector3(0,1.64f,0),new Vector3(.25f,.3f,.25f),skin);
            Box("Hair",model.head,new Vector3(0,.42f,-.02f),new Vector3(1.04f,.24f,1.04f),black);
            Box("Eyes",model.head,new Vector3(0,.04f,.51f),new Vector3(.66f,.065f,.04f),black);
            model.leftArm=Pivot("Left arm pivot",model.root,new Vector3(-.3f,1.38f,0));model.rightArm=Pivot("Right arm pivot",model.root,new Vector3(.3f,1.38f,0));
            foreach(Transform arm in new[]{model.leftArm,model.rightArm}){Box("Sleeve",arm,new Vector3(0,-.23f,0),new Vector3(.15f,.47f,.17f),cloth);Box("Hand",arm,new Vector3(0,-.53f,0),new Vector3(.13f,.14f,.14f),skin);}
            model.leftLeg=Pivot("Left leg",model.root,new Vector3(-.13f,.79f,0));model.rightLeg=Pivot("Right leg",model.root,new Vector3(.13f,.79f,0));
            foreach(Transform leg in new[]{model.leftLeg,model.rightLeg}){Box("Trouser leg",leg,new Vector3(0,-.32f,0),new Vector3(.17f,.63f,.2f),black);Box("Boot",leg,new Vector3(0,-.72f,.06f),new Vector3(.2f,.13f,.32f),black);}
            if(buddy)Box("Identity armband",model.leftArm,new Vector3(0,-.14f,0),new Vector3(.166f,.1f,.185f),Mat(fake?"Violet armband":"Blue armband",fake?new Color(.65f,.3f,.9f):new Color(.2f,.58f,.83f),0,.4f));
            if(killer){Box("Apron",model.root,new Vector3(0,.97f,.155f),new Vector3(.4f,.85f,.035f),Mat("Apron",new Color(.3f,.17f,.12f)));Box("Hood crown",model.root,new Vector3(0,1.8f,0),new Vector3(.34f,.16f,.32f),black);Box("Hood back",model.root,new Vector3(0,1.65f,-.15f),new Vector3(.34f,.35f,.1f),black);Cleaver(model.rightArm,new Vector3(0,-.5f,.1f)).localScale=Vector3.one*.65f;}
            return model;
        }
        Transform Cleaver(Transform parent,Vector3 pos)
        {
            Transform root=Pivot("Modeled cleaver",parent,pos);root.localRotation=Quaternion.Euler(-15,0,-18);
            Material leather=Mat("Glove",new Color(.22f,.24f,.2f)),bandage=Mat("Bandage",new Color(.56f,.54f,.43f));
            Box("Forearm",root,new Vector3(.02f,-.22f,-.04f),new Vector3(.17f,.32f,.18f),leather);Box("Hand",root,Vector3.zero,new Vector3(.14f,.19f,.12f),leather);
            for(int i=0;i<3;i++)Box("Bandage strip",root,new Vector3(.02f,-.12f-i*.048f,-.04f),new Vector3(.18f,.018f,.19f),bandage);
            Box("Wood handle",root,new Vector3(0,.12f,.05f),new Vector3(.055f,.32f,.06f),Mat("Handle",new Color(.25f,.13f,.065f)));
            Box("Steel blade",root,new Vector3(-.12f,.43f,.05f),new Vector3(.28f,.36f,.025f),Mat("Steel",new Color(.62f,.67f,.66f),.85f));
            Box("Blade edge",root,new Vector3(-.266f,.43f,.05f),new Vector3(.015f,.35f,.013f),Mat("Cutting edge",new Color(.87f,.89f,.83f),.9f));return root;
        }
        void Animate(ref Model model,Body body,float time,bool wounded)
        {
            Vector3 target=Position(body),delta=target-model.previous;float move=delta.sqrMagnitude>.00002f?Mathf.Sin(time*9+body.x)*24:0;
            model.root.position=target;float yaw=90-body.a*Mathf.Rad2Deg;if(delta.sqrMagnitude>.00002f&&!(body is Player))yaw=Mathf.Atan2(delta.x,delta.z)*Mathf.Rad2Deg;
            model.root.rotation=Quaternion.Euler(0,yaw,0);model.leftLeg.localRotation=Quaternion.Euler(move,0,0);model.rightLeg.localRotation=Quaternion.Euler(-move,0,0);
            model.leftArm.localRotation=Quaternion.Euler(-move*.55f,0,4);model.rightArm.localRotation=Quaternion.Euler(move*.55f,0,-4);
            Npc npc=body as Npc;if(npc!=null&&npc.wind>0)model.rightArm.localRotation=Quaternion.Euler(-110,0,-12);
            if(!body.alive||wounded){model.root.rotation=Quaternion.Euler(0,yaw,85);model.root.position=target+Vector3.up*.16f;}
            model.previous=target;
        }
        public void Display(LabyrinthGame game,int role,bool split,bool menu,float lightLevel,float thunderFlash)
        {
            if(current!=game){Build(game);}brightness=lightLevel;float time=Time.time;GameState s=game.S;
            for(int i=0;i<2;i++){Animate(ref players[i],s.players[i],time,false);Camera c=Cameras[i];bool active=split||i==role;c.gameObject.SetActive(active);c.rect=split?new Rect(i*.5f,0,.5f,1):new Rect(0,0,1,1);
                c.GetComponent<AudioListener>().enabled=i==role;c.transform.position=Position(s.players[i])+Vector3.up*1.57f;c.transform.rotation=Quaternion.Euler(-s.players[i].pitch*60,90-s.players[i].a*Mathf.Rad2Deg,0);
                float swing=s.players[i].attack>0?Mathf.Sin(s.players[i].attack/.48f*Mathf.PI):0;weapons[i].localRotation=Quaternion.Euler(-15-swing*50,-swing*25,-18-swing*55);weapons[i].gameObject.SetActive(!menu&&!(s.mode=="remote"&&i==1));}
            foreach(Npc n in s.npcs){Model model;if(!npcs.TryGetValue(n.id,out model)){model=Human("NPC "+n.id+" "+n.kind,n.kind,scenery);npcs.Add(n.id,model);}model.root.gameObject.SetActive(n.alive||s.t-n.deadAt<6);Animate(ref model,n,time,n.kind=="wounded");npcs[n.id]=model;}
            string w=menu?"clear":game.CurrentWeather.id;Color ambient=new Color(.14f,.19f,.18f),fog=new Color(.065f,.1f,.095f);float density=.022f;
            if(w=="fog"){density=.2f;ambient=new Color(.24f,.27f,.25f);fog=new Color(.25f,.29f,.26f);}if(w=="blood"){ambient=new Color(.21f,.07f,.05f);fog=new Color(.14f,.026f,.02f);}if(w=="sand"){density=.08f;ambient=new Color(.27f,.2f,.11f);fog=new Color(.25f,.19f,.1f);}if(w=="rain"){ambient=new Color(.12f,.17f,.22f);fog=new Color(.075f,.12f,.16f);}
            RenderSettings.ambientLight=ambient*brightness;RenderSettings.fogColor=fog;RenderSettings.fogDensity=density;sun.color=w=="blood"?new Color(.85f,.26f,.16f):new Color(.6f,.73f,.8f);sun.intensity=.22f*brightness+thunderFlash*2;
            for(int i=0;i<2;i++)Cameras[i].backgroundColor=fog;
            foreach(Room r in s.rooms){Light lamp=lamps[r.id];float nearest=(Position(s.players[role])-lamp.transform.position).sqrMagnitude;if(split)nearest=Mathf.Min(nearest,(Position(s.players[1-role])-lamp.transform.position).sqrMagnitude);
                lamp.enabled=nearest<230&&!r.ruined;lamp.color=r.blast>0||w=="blood"?new Color(.94f,.23f,.1f):new Color(.76f,.86f,.69f);lamp.intensity=brightness*(r.blast>0?2+Mathf.Sin(time*24):1.9f);ruins[r.id].gameObject.SetActive(r.ruined);}
            foreach(Transform part in portal)part.GetComponent<Renderer>().sharedMaterial=s.exitOpen?Mat("Exit open",new Color(.93f,1,.75f),0,2):Mat("Exit dormant",new Color(.34f,.4f,.32f),.1f);
            bool particles=!menu&&(w=="rain"||w=="sand"||w=="blood");for(int i=0;i<weatherBits.Count;i++){Transform bit=weatherBits[i];bit.gameObject.SetActive(particles);if(!particles)continue;Vector3 origin=Position(s.players[split?i%2:role]);float x=Mathf.Repeat(i*2.317f+time*(w=="sand"?6:.1f),14)-7,z=Mathf.Repeat(i*3.733f,14)-7,y=Mathf.Repeat(i*.231f-time*(w=="blood"?.2f:4),3.4f);bit.position=origin+new Vector3(x,y,z);bit.localScale=w=="sand"?new Vector3(.12f,.025f,.025f):w=="blood"?Vector3.one*.028f:new Vector3(.012f,.17f,.012f);}
            weather=w;
        }
        void Batch(string name,GeometryBatch batch,Material material){if(batch.vertices.Count==0)return;GameObject o=new GameObject(name);o.transform.SetParent(scenery,false);Mesh m=batch.Build();ownedMeshes.Add(m);o.AddComponent<MeshFilter>().sharedMesh=m;o.AddComponent<MeshRenderer>().sharedMaterial=material;}
        void OnDestroy(){foreach(Material m in materials.Values)Destroy(m);foreach(Mesh m in ownedMeshes)Destroy(m);}
        class GeometryBatch
        {
            public readonly List<Vector3> vertices=new List<Vector3>();readonly List<Vector3> normals=new List<Vector3>();readonly List<int> indices=new List<int>();
            public void Cube(Vector3 center,Vector3 size){Vector3[] dirs={Vector3.forward,Vector3.back,Vector3.right,Vector3.left,Vector3.up,Vector3.down};foreach(Vector3 n in dirs){Vector3 u=Mathf.Abs(n.y)>.5f?Vector3.right:Vector3.up;Vector3 v=Vector3.Cross(n,u);int start=vertices.Count;
                    Vector3[] offsets={n-u-v,n+u-v,n+u+v,n-u+v};foreach(Vector3 offset in offsets){vertices.Add(center+Vector3.Scale(offset,size)*.5f);normals.Add(n);}indices.Add(start);indices.Add(start+1);indices.Add(start+2);indices.Add(start);indices.Add(start+2);indices.Add(start+3);}}
            public Mesh Build(){Mesh m=new Mesh();if(vertices.Count>65000)m.indexFormat=IndexFormat.UInt32;m.SetVertices(vertices);m.SetNormals(normals);m.SetTriangles(indices,0);m.RecalculateBounds();return m;}
        }
    }
}
