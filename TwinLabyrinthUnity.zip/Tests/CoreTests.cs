using System;
using System.Collections.Generic;
using TwinLabyrinth;
class CoreTests {
 static int count;static void Check(bool v,string name){if(!v)throw new Exception(name);count++;}
 static void Main(){
  for(int seed=1;seed<=300;seed++){
   var g=new LabyrinthGame(seed,"normal","solo","elite");Check(g.S.rooms.Length==24,"rooms");
   foreach(var r in g.S.rooms){Check(r.x2-r.x1+1==4||r.x2-r.x1+1==6,"compact size");Check(!g.Wall(r.cx,r.cy),"room floor");var step=g.PathStep(g.S.players[0],new Point(r.cx,r.cy));Check(LabyrinthGame.Distance(step.x,step.y,g.S.players[0].x,g.S.players[0].y)>.01f,"connected maze");}
   for(int i=0;i<40;i++)g.Tick(.02f,new[]{new PlayerInput{forward=1},new PlayerInput()},new[]{false,true});Check(!g.Wall(g.S.players[0].x,g.S.players[0].y),"movement");
  }
  var a=new LabyrinthGame(42,"normal","local","elite");a.S.players[0].inv=0;a.S.players[1].inv=0;a.Hurt(new List<int>{0,1},"test");Check(a.S.armor==0&&a.S.used==1&&a.S.status=="playing","shared armor");a.S.players[0].inv=0;a.Hurt(new List<int>{0},"test");Check(a.S.status=="lost","death");
  var b=new LabyrinthGame(7,"normal","remote","elite");b.S.npcs.Clear();b.S.order[0]=3;b.EnterWeather();b.S.players[0].a=0;b.S.players[1].x=b.S.players[0].x+1;b.S.players[1].y=b.S.players[0].y;b.Attack(0);Check(b.S.cured&&b.S.poison==0,"blood cure");
  b.S.exitOpen=true;foreach(var p in b.S.players){p.x=44;p.y=28;}b.Tick(.02f,new[]{new PlayerInput(),new PlayerInput()},new[]{false,false});Check(b.S.status=="won","paired exit");
  Console.WriteLine("PASS "+count+" core assertions across 300 maps");
 }
}
