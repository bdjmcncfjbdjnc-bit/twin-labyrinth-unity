param([Parameter(Mandatory=$true)][string]$UnityEditor,[ValidateSet('Windows','WebGL')][string]$Target='Windows')
$ErrorActionPreference='Stop'
if (!(Test-Path -LiteralPath $UnityEditor -PathType Leaf)) {throw 'Unity Editor executable not found'}
$project=Split-Path $PSScriptRoot -Parent
& $UnityEditor -batchmode -quit -projectPath $project -executeMethod "TwinLabyrinth.LabyrinthBuild.$Target" -logFile "$project/Build-$Target.log"
if ($LASTEXITCODE -ne 0) {throw "Build failed. Read Build-$Target.log"}
